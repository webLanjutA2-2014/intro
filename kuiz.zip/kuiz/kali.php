<?php

$angka1=4;

$angka2=3;

$prosesKali=$angka1*$angka2;

print("Hasil dari $angka1 dikali dengan $angka2 adalah $prosesKali");
?>